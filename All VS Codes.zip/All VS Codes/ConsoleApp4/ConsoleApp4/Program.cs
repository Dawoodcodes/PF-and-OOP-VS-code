﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {


            //Class1 std = new Class1();
            //std.alorithum1(0);
            //Console.ReadLine();


            son sn = new son();
            sn.sonfamilyno();
            Console.ReadLine();




















            //circle c1 = new circle(5);
            //float area=c1.claculatearea();
            //Console.WriteLine(area);
            //Console.ReadLine();




















        }

    }
    public class father
    {
        protected string familyno;


    }


    public class son : father
    {
        public int sonfamilyno()
        {
            familyno = "5";
            Console.WriteLine("Family Members:" + familyno);
            return (0);
        }
    }
}
public class Class1
    {

        public string alorithum1(int thresholdvalue)
        {
            string d = "working";
            string d1 = "not working";

            thresholdvalue = 122;
            Console.WriteLine("input vvalue");
            int thrhld = Convert.ToInt32(Console.ReadLine());


            if (thrhld > thresholdvalue)
            {
                Console.WriteLine(d);
            }
            else
            {
                Console.WriteLine(d1);
            }

            return ("");

        }


        //public static class temperaturecon
        //{
        //    public static double celiustoforh(string temperturecelius)
        //    {
        //        double celius=double.Parse(temperturecelius);
        //        double fahren = (celius * 9 / 5) + 32;
        //        return fahren;

        //    }
        //    public static double farenhit(string temperaturefahrn)
        //    {
        //        double fahren = double.Parse(temperaturefahrn);
        //        double celius = (fahren - 32) * 5 / 9;
        //        return celius;
        //    }

        //}
        //class testtemperature
        //{
        //    static void Main()
        //    {
        //        Console.WriteLine("please select converter");
        //        Console.WriteLine("1.c to f");
        //        Console.WriteLine("2.f to c");
        //        Console.WriteLine(":");
        //        string selection = Console.ReadLine();
        //        double F, C = 0;
        //        switch(selection)
        //        {
        //            case "1":
        //                Console.Write("enter celius");
        //                F = temperaturecon.celiustoforh(Console.ReadLine());
        //                Console.WriteLine("temperature in fahrenheit : {0:F2}", F);
        //                break;

        //                case"2":
        //                Console.Write("enter fahren");
        //                C = temperaturecon.farenhit(Console.ReadLine());
        //                Console.WriteLine("temperature in celcius : {0:F2}", C);
        //                break;

        //            default:
        //                Console.WriteLine("Please select a convert.");
        //                break;

        //        }
        //        Console.WriteLine("Exit");
        //        Console.ReadLine();


        //    }
        //}

        class circle
        {
            static float _PI = 3.141f;
            int _Radius;
            public circle(int Radius)
            {
                this._Radius = Radius;

            }
            public float claculatearea()
            {
                return _PI * _Radius * _Radius;
            }
        }




























    }

