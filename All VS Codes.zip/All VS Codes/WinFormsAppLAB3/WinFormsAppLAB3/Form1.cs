namespace WinFormsAppLAB3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CLSCOUNTRY[] ARRCTRY = new CLSCOUNTRY[]
            {
    new CLSCOUNTRY{TEXT="PAKISTAN",VALUE="92" },
    new CLSCOUNTRY{TEXT="INDIA",VALUE="91"} };

            CB_COUNTRY.DataSource = ARRCTRY;
            CB_COUNTRY.ValueMember = "VALUE";
            CB_COUNTRY.DisplayMember = "TEXT";
        }

        private void CB_COUNTRY_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CB_COUNTRY.SelectedValue.ToString() == "92")
            {
                CLSCITY[] ARRCTY = new CLSCITY[]
                {
    new CLSCITY{TEXT="KARACHI",VALUE="92_1" },
    new CLSCITY{TEXT="LAHORE",VALUE="92_2"},
            new CLSCITY{TEXT="BAHAWALPUR",VALUE="92_3"}};
                CB_CITY.DataSource = ARRCTY;
                CB_CITY.ValueMember = "VALUE";
                CB_CITY.DisplayMember = "TEXT";
            }
            else
            {
                CLSCITY[] ARRCTY = new CLSCITY[]
        {
        new CLSCITY{TEXT="DELHI",VALUE="91_1" },
    new CLSCITY{TEXT="BOMBAY",VALUE="91_2"},
            new CLSCITY { TEXT = "GUJRAT", VALUE = "921_3" }};

                CB_CITY.DataSource = ARRCTY;
                CB_CITY.ValueMember = "VALUE";
                CB_CITY.DisplayMember = "TEXT";
            }
        }
        public class CLSCOUNTRY
        {
            public string TEXT { get; set; }
            public string VALUE { get; set; }

        }
        public class CLSCITY
        {
            public string TEXT { get; set; }
            public string VALUE { get; set; }

        }
    }
}