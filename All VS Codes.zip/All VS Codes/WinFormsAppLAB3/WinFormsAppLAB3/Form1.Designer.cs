﻿namespace WinFormsAppLAB3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CB_COUNTRY = new System.Windows.Forms.ComboBox();
            this.CB_CITY = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CB_COUNTRY
            // 
            this.CB_COUNTRY.FormattingEnabled = true;
            this.CB_COUNTRY.Location = new System.Drawing.Point(200, 181);
            this.CB_COUNTRY.Name = "CB_COUNTRY";
            this.CB_COUNTRY.Size = new System.Drawing.Size(121, 23);
            this.CB_COUNTRY.TabIndex = 0;
            this.CB_COUNTRY.SelectedIndexChanged += new System.EventHandler(this.CB_COUNTRY_SelectedIndexChanged);
            // 
            // CB_CITY
            // 
            this.CB_CITY.FormattingEnabled = true;
            this.CB_CITY.Location = new System.Drawing.Point(539, 181);
            this.CB_CITY.Name = "CB_CITY";
            this.CB_CITY.Size = new System.Drawing.Size(121, 23);
            this.CB_CITY.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(136, 189);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "COUNTRY:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(499, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "CITY:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 478);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CB_CITY);
            this.Controls.Add(this.CB_COUNTRY);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox CB_COUNTRY;
        private ComboBox CB_CITY;
        private Label label1;
        private Label label2;
    }
}