﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5lab6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                student std = new student();
                Console.ReadLine();
                
            }
        }
    }
    }
    class landtransport 
    { public string color;
        public int engine;
        public void printdata()
        { Console.WriteLine("Color is " + color);
            Console.WriteLine("Engine health is " + engine); } }
    class Car : landtransport
    { public int Wheels;
        public int Door;
        public void pdata()
        { Console.WriteLine("Wheels is " + Wheels);
            Console.WriteLine("Door is " + Door); } }
    class Bus : landtransport
    { public int Door;
        public int Numberofpassenger;
        public void pdata()
        { Console.WriteLine("Wheels is " + Numberofpassenger);
            Console.WriteLine("Door is " + Door); } }
    class truck : landtransport
    { public int space;
        public int Door;
        public void pdata()
        { Console.WriteLine("Wheels is " + space);
            Console.WriteLine("Door is " + Door); } }
    class bicycle : landtransport
    { public int Wheels;
        public void pdata()
        
        { Console.WriteLine("Wheels is " + Wheels);
            
        } }


//class human
//{
//    public string Name;
//    public char Gender;
//    public human() : this("M.dawood", 'M')
//    { Console.WriteLine("d"); }


//    public human(string name, char gender) { 
//        this.Name = name;
//        this.Gender = gender;
//        Console.WriteLine("name" + name);
//        Console.WriteLine("gender" + gender); }
//}
//class student : human
//{ public string previousEducation;
//    public student() { }
//    public student(string e)
//    { 
//        this.previousEducation = e; }
//}KKKKK
public class human
{
    public string name;
    public char gender;
    public human()//:base("dawood",'m')
    {
        this.name = "dawood";
        this.gender = 'm';

    }
    //public human(string message)
    //{
    //    Console.WriteLine(message);

    //} 
}
    public class student : human
    {
        public string education;
        public student()
        {
            this.education = "matric";
        Console.WriteLine(education,name,gender);
        }

    }



