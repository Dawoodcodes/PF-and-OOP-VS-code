﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finalpracice
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Human h = new Human();
            //h.learn();
            //h.speak();
            //h.climb();
            //h.think();

            //Console.WriteLine("\n");

            //Dog d = new Dog("lucifer", 22);
            //d.learn();
            //d.protectedOwner();
            //d.remember();
            //Console.WriteLine(d.Display());

            //Console.WriteLine("\n");

            //Cat c = new Cat("lucy", 16);
            //c.protectOwner();
            //c.climb();
            //Console.WriteLine(c.Display());
            //Console.ReadLine();
            //Dog d = new Dog();
            //d.SetName(Console.ReadLine());
            //Console.WriteLine(d.GetName());
            //d.Eat();
            //Console.ReadLine();
            //            Car myCar = new Car(0);

            //            Console.WriteLine("Enter amount of gasoline to refuel:");
            //            int gasoline = int.Parse(Console.ReadLine());
            //            myCar.Refuel(gasoline);

            //            myCar.Drive();
            //            Console.ReadLine();
            //        }
            //    }


            //    interface IVehiculo
            //    {
            //        void Drive();
            //        bool Refuel(int gasoline);
            //    }

            //    class Car : IVehiculo
            //    {
            //        public int Gasoline { get; set; }

            //        public Car(int gasoline)
            //        {
            //            Gasoline = gasoline;
            //        }

            //        public void Drive()
            //        {
            //            if (Gasoline > 0)
            //            {
            //                Console.WriteLine("The car is driving.");
            //                Gasoline--;
            //            }
            //            else
            //            {
            //                Console.WriteLine("Not enough gasoline. Please refuel.");
            //            }
            //        }

            //        public bool Refuel(int gasoline)
            //        {
            //            Gasoline += gasoline;
            //            return true;
            //        }
            //    }
            //}


            PhotoBook pb = new PhotoBook();
            Console.WriteLine(pb.GetPages());
            PhotoBook pb1 = new PhotoBook(24);
            Console.WriteLine(pb1.GetPages());
            BigPhotoBook bbw = new BigPhotoBook();
            Console.WriteLine(bbw.GetPages());
            Console.ReadLine();
        }

    }

    class PhotoBook
    {
        protected int numPages;

        public int GetPages()
        {
            return numPages;
        }

        public PhotoBook()
        {
            numPages = 16;
        }
        public PhotoBook(int n)
        {
           numPages = n;
        }
    }
    class BigPhotoBook : PhotoBook
    {

        public BigPhotoBook()
        {
            numPages = 64;
        }
    }
}
//abstract class Animal
//{
//    private string name;

//    public void SetName(string n)
//    {
//        this.name = n;
//    }
//    public string GetName()
//    {
//        return this.name;
//    }
//    public abstract void Eat();
//}

//class Dog : Animal
//{
//    public override void Eat()
//    {
//        Console.WriteLine("kha rhe hain.");
//    }
//    interface IClimb { void climb(); }

//    interface ILearn { void learn(); }
//    interface IThink { void think(); }
//    interface ISpeak { void speak(); }


//    class Human : IClimb, ILearn, IThink, ISpeak
//    {
//        public Human()
//        {

//        }
//        public void think()
//        {
//            Console.WriteLine("i can think.");
//        }
//        public void speak()
//        {
//            Console.WriteLine("i can speak.");
//        }
//        public void climb()
//        {
//            Console.WriteLine("i can climb.");
//        }
//        public void learn()
//        {
//            Console.WriteLine("i can learn.");
//        }
//    }
//    class Animal
//    {
//        protected string name;
//        protected int lifeExp;

//        public Animal(string n, int life)
//        {
//            this.name = n;
//            this.lifeExp = life;
//        }
//        public void remember()
//        {
//            Console.WriteLine("I always remember");
//        }
//        public void protectOwner()
//        {
//            Console.WriteLine("protect karega.");
//        }
//        public string Display()
//        {
//            return ("Animal name is {0}" + this.name + "Animal life Expentency is {0}" + this.lifeExp);
//        }
//    }
//    class Dog : Animal, ILearn  
//    {
//        string name;
//        public Dog(string name, int life) : base(name, life)
//        {

//        }
//        public void remember()
//        {
//            Console.WriteLine("mujhe sab yaad rehta hai.");
//        }
//        public void protectedOwner()
//        {
//            Console.WriteLine("mein sab se bachata hun.");
//        }
//        public void learn()
//        {
//            Console.WriteLine("mein sab seekhta hun.");
//        }
//    }
//    class Cat : Animal, IClimb
//    {
//        public Cat(string name, int life) : base(name, life)
//        {
//        }
//        public void remember()
//        {
//            Console.WriteLine("mujhe sab yaad rehta hai,");
//        }
//        public void protectOwner()
//        {
//            Console.WriteLine("choohay ki . ");
//        }
//        public void climb()
//        {
//            Console.WriteLine("mein 6ft upar charh skti hun. ");
//        }
//    }


//}



