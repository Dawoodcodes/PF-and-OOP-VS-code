﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4assig1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            case1();
            case2();
            case3();
            case4();
            case6();
            case7();
            
            Console.ReadLine();

        }

        public static string case1()
        {
            string name = "ali";
           
            return "ali";
        }
        public static int[] case2()
        {
            int[] array = { 2, 3, 4, 5 };
           

            return array;
        }
      public static string case3()
        {
            string name = "ali";

            name = ",";
            name = "anas";
            name = ",";
            name = "sabor";
            name = ",";
            name = "waqas";
            Console.WriteLine(name);

            return name;

        }
        public static void case4()
        {
            student std1 = new student();
            std1.stdname = "sabor";
            std1.stdid = 14515;
            std1.stdage = 19;
            std1.stdgender = "male";
          

            return;
        }
        public static object case6()
        {
            object objname = "sabor";
            return objname;
        }
        public static dynamic case7()
        {
            dynamic age = 12;
           

            return age;
        }

        
    }
    public class student
    {
        public string stdname;
        public int stdid;
        public int stdage;
        public string stdgender;

    }

}
