﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4assig1
{
    internal class Class1
    {
        string _Name;
        int _age;
        public Class1(string name, int age)
        {
            this._Name = name;
            this._age = age;
        }
        public void printpersondata()
        {
            Console.WriteLine("Your Name is " + _Name + "your age is" + _age);
        }
    }
}
