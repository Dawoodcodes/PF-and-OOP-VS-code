using System.Data;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
             SqlConnection con = new SqlConnection(@"Data Source=-ROCKSTAR-\SQLEXPRESS;Initial Catalog=exxp;Integrated Security=True");
        string query = " UPDATE table_3 SET CountryName = '99' WHERE ID = 2 ";
            SqlCommand command = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataAdapter DataAdapter = new SqlDataAdapter(command);
            DataAdapter.Fill(dt);
            dataGridView1.DataSource=dt;
            //int a =command.ExecuteNonQuery();
            con.Close();
           
        }
    }
}