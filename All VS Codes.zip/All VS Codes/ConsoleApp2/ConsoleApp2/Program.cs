﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int leap_year;
            Console.WriteLine("enter year");
            leap_year =Convert.ToInt32(Console.ReadLine());
            if((leap_year %4)==0)
                Console.WriteLine("{0} is a leap_year",leap_year);
                
            else
                Console.WriteLine("{0} is noy  a leap_year", leap_year);
         Console.ReadLine();    
        }
        

        }
    }

