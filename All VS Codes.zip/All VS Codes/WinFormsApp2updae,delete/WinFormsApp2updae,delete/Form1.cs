using System.Data.SqlClient;

namespace WinFormsApp2updae_delete
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=-ROCKSTAR-\SQLEXPRESS;Initial Catalog=assg;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            
            string update = "Update tbl_country set Country='PAKISTAN' where Countryid='"+txtupdate.Text+"'";
            SqlCommand cmd =new SqlCommand(update, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string delete = "delete from tbl_country where Countryid='" + txtdelete.Text + "'";
            SqlCommand cmd = new SqlCommand(delete, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}