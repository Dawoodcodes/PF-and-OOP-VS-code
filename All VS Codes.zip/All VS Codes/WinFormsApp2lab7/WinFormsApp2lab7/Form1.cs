using System;
using System.Collections.Generic;
namespace WinFormsApp2lab7
    
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student _student = new Student();
            _student.Name = "murtaza";
            List<Teacher> _lstTeachers = new List<Teacher>();
            Teacher _teacher1 = new Teacher { Name = "Aziz Mehmood" };
            Teacher _teacher2 = new Teacher { Name = "Azam Khan" };
            Teacher _teacher3 = new Teacher { Name = "Waqas pasha" };
            Teacher _teacher4 = new Teacher { Name = " sabiaka raza" };
            _lstTeachers.Add(_teacher1);
            _lstTeachers.Add(_teacher2);
            _lstTeachers.Add(_teacher3);
            _lstTeachers.Add(_teacher4);
            foreach (var s in _lstTeachers)
            {
                string name1 = s.Name;
                string name2 = s.Name;
                string name3 = s.Name;
                string name4 = s.Name;
            }
            _student.SetAssociatedTeachers(_lstTeachers);
            string lstTeachers = "";
            MessageBox.Show("Student name is " + _student.Name + "\n his teacher list is"
            + _student.GetTeacherBystudentname());
        }


    }
    public class Student
    {
        public String Name { get; set; }
        public List<Teacher> _lstTeachers { get; set; }
        public void SetAssociatedTeachers(List<Teacher> lstTeachers)
        {
            _lstTeachers = lstTeachers;
        }
        public string GetTeacherBystudentname()
        {
            string tmpteacherDetail = "";
            foreach (var t in this._lstTeachers)
            {
                tmpteacherDetail += t.Name + ",";
            }
            return tmpteacherDetail;
        }
        public class Teacher
        {
            public String Name { get; set; }
            List<Student> _lstStudents { get; set; }
        }
    }


}

