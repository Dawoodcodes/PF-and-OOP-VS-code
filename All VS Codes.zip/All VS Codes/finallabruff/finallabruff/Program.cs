﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finallabruff
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //    int fnum, snum, i, num, k;
            //    Console.WriteLine("inter fnumber");
            //    fnum = Convert.ToInt32(Console.ReadLine());
            //    Console.WriteLine("inter fnumber");
            //    snum = Convert.ToInt32(Console.ReadLine());
            //    Console.WriteLine("fvdfvdsvdfv:");
            //    for (num = fnum; num <= snum; num++)
            //    {
            //        k = 0;
            //        for (i = 2; i <= num / 2; i++)
            //        {
            //            if (num % i == 0)
            //                k++;
            //            break;
            //        }

            //        if (k == 0 && num != 1)
            //            Console.Write("{0}", num);


            //        Console.Write("\n");
            //        Console.ReadLine();
            //    }
            //}



            //int val1 = 0, val2 = 1, val3, i, n;
            //n = 10



            //    ;
            ////fabecc seree
            //for (i = 2; i < n; ++i)
            //{
            //    val3 = val1 + val2;
            //    Console.Write(val1 + "");
            //    val1 = val2;
            //    val2 = val3;
            //    Console.ReadLine();

            //}


            int a;
            a = Convert.ToInt32(Console.ReadLine());
            {
                for (int i = 0; i < 10; i++)
                    Console.WriteLine(a + "a" + i + "=" + (a * i));
                Console.ReadLine();
            }
        }
    }
}





