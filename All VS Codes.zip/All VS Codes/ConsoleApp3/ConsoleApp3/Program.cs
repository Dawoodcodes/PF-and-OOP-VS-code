﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* Student std = new Student("M.Dawood", "dawood.zahid035@gmail.com", 19, 123456789);
             std.print();
             Console.WriteLine();
             Console.ReadLine();*///Q1
            /* Programming pro = new Programming();
             pro.print();
             Programming pro1 = new Programming("kiet");
             pro1.print1();

             Console.WriteLine();
             Console.ReadLine();*///Q2
            Rectangle rect = new Rectangle();
            rect.print();
            Rectangle rect1 = new Rectangle(4, 5);
            rect1.print();
            Rectangle rect2 = new Rectangle(6);
            rect2.print();

            Console.WriteLine();

            Console.ReadLine();
        
}
    }
    class Rectangle
    {
        int length;
        int bredth;
        public Rectangle()
        {
            length = 0;
            bredth = 0;
        }
        public Rectangle(int length, int bredth)
        {
            this.length = length;
            this.bredth = bredth;
        }
        public Rectangle(int val)
        {
            this.length = val;
            this.bredth = val;
        }
        public void print()
        {
            Console.WriteLine("The Area Is: " + (length * bredth));
        }
    }
    /* class Programming
     {
         string msg;

         public Programming()
         {
             msg = "I Love Programming";
         }

         public Programming(string msg)
         {
             this.msg = msg;
         }

         public void print()
         {
             Console.WriteLine(msg);
         }

         public void print1()
         {
             Console.WriteLine("I Love " + msg);
         }
     }*///Q2
    /*class Student
    {
        string name;
        int age;
        string email;
        int phone;

        public Student(string name, string email, int age, int phone)
        {
            this.name = name;
            this.age = age;
            this.email = email;
            this.phone = phone;
        }

        public void print()
        {
            Console.WriteLine("The Name Is: " + name + 
                "\nThe Age Is: " + age + "\nThe Email Is: " + email + 
                "\nThe Phone Is: " + phone);
        }*///Q1
}
    
