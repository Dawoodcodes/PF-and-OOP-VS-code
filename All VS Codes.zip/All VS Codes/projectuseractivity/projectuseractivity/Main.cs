﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace projectuseractivity
{
    internal class Main
    {
        private SqlConnection connection;
        public static SqlConnection getconnection()
        {
            SqlConnection connection = new SqlConnection(@"Data Source=-ROCKSTAR-\SQLEXPRESS;Initial Catalog=Login;Integrated Security=True");
            return connection;
        }

        public string Converter_string(string SQL)
        {
            try
            {
                SqlConnection con = Main.getconnection();
                DataTable consultantable = new DataTable();
                string StringConsultant;
                SqlDataAdapter Consultantdataadapter = new SqlDataAdapter(SQL, con);
                Consultantdataadapter.Fill(consultantable);
                foreach (DataRow myrow in consultantable.Rows)
                {
                    StringConsultant = Convert.ToString(myrow[0]);
                    return StringConsultant;
                }

            }
            catch
            {
                throw;
            }
            return "0";
        }
        public void Excute(string SQL)
        {
            try
            {
                SqlConnection con = Main.getconnection();
                DataTable consultantable = new DataTable();
                SqlDataAdapter Consultantdataadapter = new SqlDataAdapter(SQL, con);
                Consultantdataadapter.Fill(consultantable);
            }
            catch
            {
                throw;
            }
        }
    }
}
