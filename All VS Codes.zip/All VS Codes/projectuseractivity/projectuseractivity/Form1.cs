using System.Data.SqlClient;
using System.Net;
using System.Data;

namespace projectuseractivity
{
    public partial class frmLogin : Form
    {
        public FrmLogin()
        public static string CIP = "";
        public static string EmpNo = "1";
        public static string username = "1";

        SqlConnection connection = Main.getconnection();

        private void getIP()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily.ToString() == "INterNETWORK")
                {
                    CIP = ip.ToString();


                }
            }
            IbICP.Text = CIP;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if ((txtusername.Text == ""))
            {
                MessageBox.Show("PLease enter username");
            }
            else if ((txtpassword.Text == ""))
            {
                MessageBox.Show("PLease enter Password");
            }
            else
            {
                string Login = "Login";
                Main code = new Main();
                string SqlEmpNo = "Select EmployeeNO Login where username='" + Convert.ToString(txtusername.Text) + "' AND PASSWORD='" + Convert.ToString(txtpassword.Text) + "'";
                EmpNo = code.Converter_string(SqlEmpNo).ToString();
                if (EmpNo != "")
                {
                    string SqlLoginName = "select username from Login where EmployeeNo='" + Convert.ToString(EmpNo) + "'";
                    username = code.Converter_string(SqlLoginName).ToString();
                    code.Excute(@"insert into User_Activity_Log values('" + Convert.ToString(txtusername.Text) + "','" + EmpNo + "','" + DateTime.Now + "','" + Login + "','" + CIP + "')");


                    FrmActivity frmmain = new FrmActivity();
                    this.Hide();
                    frmmain.Show();

                }
                else
                {
                    MessageBox.Show("invalid password");
                    txtpassword.Text = "";
                }
            }
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {
            getIP;
        }
    }
}
    
