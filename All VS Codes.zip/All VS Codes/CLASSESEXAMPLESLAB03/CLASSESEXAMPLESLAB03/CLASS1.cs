﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLASSESEXAMPLESLAB03
{
    internal class CLASS1
    {
        string _Name;
        int _Age;
        public CLASS1(string name, int age)
        {
            this._Age = age;
            this._Name = name;
        }
        public void PrintPersonData()
        {
            Console.WriteLine("Person Name is " + _Name + " and Person Age is" + _Age);
        }
    }
}
