﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLASSESEXAMPLESLAB03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CLASS1 obj1 = new CLASS1("Dawood", 19);
            CLASS1 obj2 = new CLASS1("Ali", 20);
            CLASS1 obj3 = new CLASS1("Ahmed", 25);
            obj1.PrintPersonData();
            obj2.PrintPersonData();
            obj3.PrintPersonData();
            Console.ReadLine();
        }
    }
}
