﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ConsoleApp4lab2sql
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection(@"Data Source=-ROCKSTAR-\SQLEXPRESS;Initial Catalog=assg;Integrated Security=True");
            string query = "select*from Table1";
            SqlCommand Command=new SqlCommand(query, con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataAdapter DataAdapt=new SqlDataAdapter(Command);
            DataAdapt.Fill(dt);
            con.Close();
            Console.ReadLine();
        }
    }
}
