﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

namespace rufff
{
    internal class Program
    {
        static void Main(string[] args)

        //        {

        //            FileStream fs = new FileStream("e:\\test3.txt", FileMode.Append, FileAccess.Write);
        //            StreamWriter sw = new StreamWriter(fs);



        //                float i;
        //                for (i = 2; i <= 15; i++)
        //                    Console.WriteLine(i);

        //                sw.WriteLine(i);

        //                Console.ReadLine();


        //            sw.Close(); fs.Close();
        //        }
        //    }
        //}

        //{
        //    FileStream fs1 = new FileStream("f:\\daw.txt", FileMode.Open, FileAccess.Read);
        //    StreamReader sr1 = new StreamReader(fs1);
        //    string str1 = sr1.ReadLine();
        //    while (str1 != null)
        //    {
        //        Console.WriteLine(str1);
        //        str1 = sr1.ReadLine();
        //    }
        //    sr1.Close();
        //    fs1.Close();
        //    Console.ReadKey();
        //}

        { FileStream fs = new FileStream("f:\\daw.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            Console.Write("Enter Name to search ");
            string input = Console.ReadLine();
            string str = sr.ReadLine();
            while (str != null) 
            { if (str.Contains(input)) 
                { Console.WriteLine("Found"+str);
                } 
                str = sr.ReadLine();
            } Console.ReadLine();
            sr.Close();
            fs.Close(); }
    }
}





