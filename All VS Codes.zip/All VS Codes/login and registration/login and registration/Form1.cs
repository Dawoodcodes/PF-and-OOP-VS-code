using System.Data.SqlClient;

namespace login_and_registration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        SqlConnection con = new SqlConnection(@"Data Source=-ROCKSTAR-\SQLEXPRESS;Initial Catalog=Login;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txtusername.Text==""&& txtpassword.Text==""&& txtconpassword.Text=="")
            {
                MessageBox.Show("username and password fields are empty","sign up failed",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else if(txtpassword.Text==txtconpassword.Text)
            {
                con.Open();
                string register = "insert into tbl_users Values('" + txtusername.Text + "','" + txtpassword.Text + "','"+ DateTime.Now+"')";
                cmd = new SqlCommand(register,con);
                cmd.ExecuteNonQuery();
                con.Close();

                txtusername.Text = "";
                txtpassword.Text = "";
                txtconpassword.Text = "";
                MessageBox.Show("Your account has been created","registration sucess",MessageBoxButtons.OK,MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("password doesnt match,please retry", "registration failef", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtpassword.Text = "";
                txtconpassword.Text = "";
                txtpassword.Focus();

            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBcshowpas.Checked)
            {
                txtpassword.PasswordChar = '\0';
                txtconpassword.PasswordChar = '\0';
            }
            else
            {
                txtpassword.PasswordChar = '*';
                txtconpassword.PasswordChar = '*';
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtusername.Text = "";
            txtpassword.Text = "";
            txtconpassword.Text = "";
            txtusername.Focus();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            new FrmLogin().Show();
            this.Hide();

        }

        private void txtusername_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}