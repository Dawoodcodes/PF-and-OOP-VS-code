﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pf_examples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* int a, b, c, x;
             a = 80;
             b = 15;
             c = 2;
             x = a - b / (3 * c) * (a + c);
             Console.WriteLine(x);
             Console.ReadLine();*/



            /*  int a = 5;
              int b = 10;
              int c;
              Console.WriteLine(c = ++a + b++);
              Console.WriteLine(b);
              Console.ReadLine();*/



            /* int num = 123;
             Console.WriteLine(num);
             int First = num / 100;
             Console.WriteLine(First);
             int r = num % 100;
             Console.WriteLine(r);
             int Second = r / 10;
             Console.WriteLine(Second);
             int Third = num % 10;
             Console.WriteLine(Third);


             int Sum = First + Second + Third;
             Console.WriteLine();
             Console.WriteLine(Sum + "Sum of" + num);*/




            /*  int a = 5, b = 6, c;
              Console.WriteLine(a + "" + b);
              c = a;
              a = b;
              b = c;
              Console.WriteLine(a + "" + b);*/




            Console.WriteLine("Please enter masss of an object");
            double mass = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter acceleration");
            double acceleration = Convert.ToDouble(Console.ReadLine());
            double Force = mass * acceleration;
            Console.WriteLine(Force);


        }
    }
}
