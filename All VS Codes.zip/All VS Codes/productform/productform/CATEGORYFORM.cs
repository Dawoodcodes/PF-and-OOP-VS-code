﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace productform
{
    public partial class CATEGORYFORM : Form
    {
        public CATEGORYFORM()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=-RoCkStAr-\sqlexpress;Integrated Security=True");

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
        private void populate()
        {
            con.Open();
            string query = "select * from CategoryTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder biulder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            CAtDGV.DataSource = ds.Tables[0];
            con.Close();

        }

        private void button7_Click(object sender, EventArgs e)
        {

            try
            {

                con.Open();
                string query = "insert into CategoryTbl values(" + catIDTb.Text + ",'" + CatNameTb.Text + "','" + CatDescTb.Text + "')";
                SqlCommand cmd=new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("CAtegory added succesfully");
                con.Close();
                //populate();
                //catIDTb.Text = "";
                //CatNameTb.Text = "";
                //CatDescTb.Text = "";
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CATEGORYFORM_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void CAtDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            catIDTb.Text = CAtDGV.SelectedRows[0].Cells[0].Value.ToString();
           CatNameTb.Text = CAtDGV.SelectedRows[0].Cells[1].Value.ToString();
            CatDescTb.Text =CAtDGV.SelectedRows[0].Cells[2].Value.ToString();

        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                if (catIDTb.Text == "")
                {
                    MessageBox.Show("Select Category Id to Delete");
                }
                else
                {
                    con.Open();
                    string query = "delete from CategoryTbl where Catid=" + catIDTb.Text + "";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category has been deleted successfully");
                    con.Close();
                    populate();
                    catIDTb.Text = "";
                    CatNameTb.Text = "";
                    CatDescTb.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            Form1 Prod = new Form1();
            Prod.Show();
            this.Hide();
        }

        private void btnSellers_Click(object sender, EventArgs e)
        {
            Sellerform Sell = new Sellerform();
            Sell.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                if (catIDTb.Text == "" || CatNameTb.Text == "" || CatDescTb.Text == "")
                {
                    MessageBox.Show("Missing Information");
                }
                else
                {
                    con.Open();
                    string query = "update CategoryTbl set CatName='" + CatNameTb.Text + "',CatDesc='" + CatDescTb.Text + "' where CatId=" + catIDTb.Text + "";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category has been updated Successfully");
                   con.Close();
                   // populate();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
