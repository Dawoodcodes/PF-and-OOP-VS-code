﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dawood.ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*string name = "Ali";
            long x=1000000;
 float percent= 73.56f;
 double d= 327.454;
            Console.WriteLine(" Name = "+ name);
            Console.WriteLine("x = "+ x);
            Console.WriteLine("percent = "+ percent);
            Console.WriteLine("d = "+ d);*/
            int salary, tax, b, ns = 0;

            Console.WriteLine("Input Salary");
            salary = Convert.ToInt32(Console.ReadLine());
            tax = 3 * salary / 100;
            b=5*salary / 100;
            ns = salary - tax + b;
            Console.WriteLine("Salary="+salary);
            Console.WriteLine("Tax:"+tax);
            Console.WriteLine("Bonus" + b);
            Console.WriteLine("Net Salary" + ns);
            /*int expense, income, m_Saving=0;
            Console.WriteLine("Input income");
            income=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input expense");
            expense=Convert.ToInt32(Console.ReadLine());
            m_Saving = income - expense;
            Console.WriteLine("your saving is" + m_Saving);*/


        }
    }
}
