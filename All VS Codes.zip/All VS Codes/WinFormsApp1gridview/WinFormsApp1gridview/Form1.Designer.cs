﻿namespace WinFormsApp1gridview
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.CLMNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CLMFATHER = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CLMSTATUS = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.CLMINCOME = new System.Windows.Forms.DataGridViewComboBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CLMNAME,
            this.CLMFATHER,
            this.CLMSTATUS,
            this.CLMINCOME});
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView1.Location = new System.Drawing.Point(105, 42);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(609, 343);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // CLMNAME
            // 
            this.CLMNAME.HeaderText = "NAME";
            this.CLMNAME.Name = "CLMNAME";
            this.CLMNAME.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // CLMFATHER
            // 
            this.CLMFATHER.HeaderText = "FATHER NAME";
            this.CLMFATHER.Name = "CLMFATHER";
            // 
            // CLMSTATUS
            // 
            this.CLMSTATUS.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.CLMSTATUS.HeaderText = "STATUS";
            this.CLMSTATUS.Name = "CLMSTATUS";
            // 
            // CLMINCOME
            // 
            this.CLMINCOME.HeaderText = "INCOME";
            this.CLMINCOME.Items.AddRange(new object[] {
            "25000-40000",
            "40000-60000",
            "60000-100000"});
            this.CLMINCOME.Name = "CLMINCOME";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn CLMNAME;
        private DataGridViewTextBoxColumn CLMFATHER;
        private DataGridViewCheckBoxColumn CLMSTATUS;
        private DataGridViewComboBoxColumn CLMINCOME;
    }
}