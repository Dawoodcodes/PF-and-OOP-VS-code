namespace WinFormsApp1gridview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            SHOWDATA();
        }
        public void SHOWDATA()
        {
            Console.WriteLine("DAWOOD");
        }
    }
}