﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practicefinal
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Toyota tt = new Toyota();
            //tt.Color = "Black";
            //tt.Model = 2022;
            //tt.vehicle_name("");
            //tt.printdriverinfo();

            //Manager Man_Obj = new Manager();
            //Man_Obj.Manager_Name = "Dazy Aray";
            //Employee Emp_Obj = new Employee();
            //Emp_Obj.Emp_Name = "Ambika";
            //Emp_Obj.Manager_Name(Man_Obj);
            //Console.ReadLine();

            int[] arr=new int[3];
            for (int i = 0; i < 3; i++)
            {
                foreach (var t in arr)
                {
                    Console.WriteLine("print" + t);
                }
            }
        }
    }
    public class car
    {
        public string Color { get; set; }
        public int Model { get; set; }

    }
    public class Toyota : car
    {

        public string vehicle_name(string veh_name)
        {
            Console.WriteLine("enter vehicle name");
            veh_name = Console.ReadLine();
            return veh_name;


        }
        public void printdriverinfo()
        {
            Console.WriteLine("Coolor of car is:" + Color + "\n CAr model:" + Model);
            engine egn = new engine();
            egn.engine_power = "1800cc";
            egn.print();
        }
    }
    public class engine
    {
        public string engine_power { get; set; }
        public void print()
        {
            Console.WriteLine("engine power is:" + engine_power);
        }
    }
    class Employee
    {
        public Employee() { }
        public string Emp_Name { get; set; }

        public void Manager_Name(Manager Obj)
        {
            Obj.manager_Info(this);
        }
    }

    class Manager
    {

        public Manager() { }
        public string Manager_Name { get; set; }
        public void manager_Info(Employee Obj)
        {
            Console.WriteLine($"Manager of Employee  {Obj.Emp_Name} is  {this.Manager_Name}");

        }
    }
}
