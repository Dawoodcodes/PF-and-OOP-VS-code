﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dawood._14515.pftask12
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter Future Value : ");
            double futureVa1 = Convert.ToDouble(Console.ReadLine());


            Console.WriteLine("Enter Interest Rate : ");

            double r = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Years :");

            double year = Convert.ToDouble(Console.ReadLine());


            double p = presentValue(futureVa1, r, year);
            Console.WriteLine("THE AMOUNT WILL BE:  " + p);
            Console.ReadLine();
        }
        public static double presentValue(double futureVa1, double r, double Year)


        {
            double p = futureVa1 / Math.Pow((1 + r), Year);
            return p;
        }
    }
}
