namespace WinFormsApp1assssig01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Parcel obj = new Parcel();
            obj.id = Convert.ToInt32(tb_reveipt.Text);
            obj.sendername = tb_sendername.Text.ToString();
            obj.senderaddress = tb_senderaddress.Text.ToString();
            obj.receivername = tb_receivername.Text.ToString();
            obj.receiveraddress = tb_reveiveraddress.Text.ToString();
            obj.weight = Convert.ToInt32(tb_parcelweight.Text);
            obj.fee = Convert.ToInt32(tb_parcelshipping.Text);

            MessageBox.Show("***************Reciept*****************"+"\nID:"
                +obj.id.ToString() + "\nSender Name: " + obj.sendername + " \nAddress:"
                +obj.senderaddress + "\nReaciever Name:"+obj.receivername 
                + "\nReciaver Address:" + obj.receiveraddress + "\nWeight:"
                +obj.weight.ToString() + "\nFee:" + obj.fee.ToString()
   );
        }
    }
    class Parcel
    {
        public int id { get; set; }
        public string sendername { get; set; }
        public string senderaddress { get; set; }
        public string receivername { get; set; }
        public string receiveraddress { get; set; }
        public int weight { get; set; }
        public int fee { get; set; }

    }
}