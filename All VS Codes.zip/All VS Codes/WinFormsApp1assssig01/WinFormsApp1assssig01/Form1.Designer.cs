﻿namespace WinFormsApp1assssig01
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tb_reveipt = new System.Windows.Forms.TextBox();
            this.tb_sendername = new System.Windows.Forms.TextBox();
            this.tb_senderaddress = new System.Windows.Forms.TextBox();
            this.tb_receivername = new System.Windows.Forms.TextBox();
            this.tb_reveiveraddress = new System.Windows.Forms.TextBox();
            this.tb_parcelweight = new System.Windows.Forms.TextBox();
            this.tb_parcelshipping = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(392, 345);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 29);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tb_reveipt
            // 
            this.tb_reveipt.Location = new System.Drawing.Point(375, 68);
            this.tb_reveipt.Name = "tb_reveipt";
            this.tb_reveipt.Size = new System.Drawing.Size(157, 23);
            this.tb_reveipt.TabIndex = 1;
            // 
            // tb_sendername
            // 
            this.tb_sendername.Location = new System.Drawing.Point(375, 109);
            this.tb_sendername.Name = "tb_sendername";
            this.tb_sendername.Size = new System.Drawing.Size(157, 23);
            this.tb_sendername.TabIndex = 2;
            // 
            // tb_senderaddress
            // 
            this.tb_senderaddress.Location = new System.Drawing.Point(375, 148);
            this.tb_senderaddress.Name = "tb_senderaddress";
            this.tb_senderaddress.Size = new System.Drawing.Size(157, 23);
            this.tb_senderaddress.TabIndex = 3;
            // 
            // tb_receivername
            // 
            this.tb_receivername.Location = new System.Drawing.Point(375, 188);
            this.tb_receivername.Name = "tb_receivername";
            this.tb_receivername.Size = new System.Drawing.Size(157, 23);
            this.tb_receivername.TabIndex = 4;
            // 
            // tb_reveiveraddress
            // 
            this.tb_reveiveraddress.Location = new System.Drawing.Point(375, 223);
            this.tb_reveiveraddress.Name = "tb_reveiveraddress";
            this.tb_reveiveraddress.Size = new System.Drawing.Size(157, 23);
            this.tb_reveiveraddress.TabIndex = 5;
            // 
            // tb_parcelweight
            // 
            this.tb_parcelweight.Location = new System.Drawing.Point(375, 261);
            this.tb_parcelweight.Name = "tb_parcelweight";
            this.tb_parcelweight.Size = new System.Drawing.Size(157, 23);
            this.tb_parcelweight.TabIndex = 6;
            // 
            // tb_parcelshipping
            // 
            this.tb_parcelshipping.Location = new System.Drawing.Point(375, 294);
            this.tb_parcelshipping.Name = "tb_parcelshipping";
            this.tb_parcelshipping.Size = new System.Drawing.Size(157, 23);
            this.tb_parcelshipping.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(307, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Receipt No:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(294, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Sender Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(284, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "Sender Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(286, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "Receiver Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(276, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 15);
            this.label5.TabIndex = 12;
            this.label5.Text = "Receiver Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(292, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "Parcel Weight:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(237, 302);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(138, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "Parcel Shipping Charges:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 476);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_parcelshipping);
            this.Controls.Add(this.tb_parcelweight);
            this.Controls.Add(this.tb_reveiveraddress);
            this.Controls.Add(this.tb_receivername);
            this.Controls.Add(this.tb_senderaddress);
            this.Controls.Add(this.tb_sendername);
            this.Controls.Add(this.tb_reveipt);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button button1;
        private TextBox tb_reveipt;
        private TextBox tb_sendername;
        private TextBox tb_senderaddress;
        private TextBox tb_receivername;
        private TextBox tb_reveiveraddress;
        private TextBox tb_parcelweight;
        private TextBox tb_parcelshipping;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
    }
}