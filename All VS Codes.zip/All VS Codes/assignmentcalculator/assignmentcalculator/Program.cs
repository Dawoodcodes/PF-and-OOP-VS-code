﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator_1
{
    class Program
    {
        static void Main(string[] args)
        /*{
            string p1, p2, p3, admin;
            string pass1, pass2, pass3, adminpass;
            double add1 = 0, add2 = 0, add3 = 0;


            double sub1 = 0, sub2 = 0, sub3 = 0;

            double mul1 = 0, mul2 = 0, mul3 = 0;

            double div1 = 0, div2 = 0, div3 = 0;





            Console.WriteLine("Enter name 1: ");
            p1 = Console.ReadLine();
            Console.WriteLine("Enter Password:........... ");

            pass1 = Console.ReadLine();



            Console.Write("Enter First Number:... ");
            double n1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter Second Number: ");
            double n2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Operations: +, -, *, /");


            Console.WriteLine();
            Console.Write("Choose an Operation :...... ");
            char operation = Convert.ToChar(Console.ReadLine());
            if (operation == '+')
            {
                add1 = n1 + n2;
                Console.WriteLine("The Answer Is: " + add1);
            }
            else if (operation == '-')
            {
                sub1 = n1 - n2;
                Console.WriteLine("The Answer Is: " + sub1);
            }
            else if (operation == '*')
            {
                mul1 = n1 * n2;
                Console.WriteLine("The Answer Is: " + mul1);
            }
            else if (operation == '/')
            {
                div1 = n1 / n2;
                Console.WriteLine("The Answer Is: " + div1);
            }
            else
            {
                Console.WriteLine("Invalid Operation!");
            }
            Console.ReadKey();
            Console.Clear();





            Console.WriteLine("Enter Name 2:........ ");

            p2 = Console.ReadLine();
            Console.Write("Enter Password:.... ");

            pass2 = Console.ReadLine();

            Console.WriteLine("Enter First Number: ");
            double num1 = Convert.ToDouble(Console.ReadLine());


            Console.WriteLine("Enter Second Number: ");
            double num2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Operations: +, -, *, /");

            Console.WriteLine();
            Console.Write("Choose An Operation From Above: ");
            char ope = Convert.ToChar(Console.ReadLine());
            if (ope == '+')
            {
                add2 = num1 + num2;
                Console.WriteLine("The Answer Is: " + add2);
            }
            else if (ope == '-')
            {
                sub2 = num1 - num2;
                Console.WriteLine("The Answer Is: " + sub2);
            }
            else if (ope == '*')
            {
                mul2 = num1 * num2;
                Console.WriteLine("The Answer Is: " + mul2);
            }
            else if (ope == '/')
            {
                div2 = num1 / num2;
                Console.WriteLine("The Answer Is: " + div2);
            }
            else
            {
                Console.WriteLine("Invalid Operation!");
            }


            Console.ReadKey();
            Console.Clear();









            Console.WriteLine("Enter Name 3:............ ");
            p3 = Console.ReadLine();
            Console.WriteLine("Enter Password: ");


            pass3 = Console.ReadLine();

            Console.Write("Enter FirstNumber: ........");
            double number1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter SecondNumber:......... ");
            double number2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Operations: +, -, *, /");
            Console.WriteLine();
            Console.Write("Choose an Operation:........... ");
            char Operation = Convert.ToChar(Console.ReadLine());
            if (Operation == '+')
            {
                add3 = number1 + number2;
                Console.WriteLine("The Answer Is: " + add3);
            }
            else if (Operation == '-')
            {
                sub3 = number1 - number2;
                Console.WriteLine("The Answer Is: " + sub3);
            }
            else if (Operation == '*')
            {
                mul3 = number1 * number2;
                Console.WriteLine("The Answer Is: " + mul3);
            }
            else if (Operation == '/')
            {
                div3 = number1 / number2;
                Console.WriteLine("The Answer Is: " + div3);
            }
            else
            {
                Console.WriteLine("Invalid Operation!");
            }
            Console.ReadKey();
            Console.Clear();
            Console.Write("Enter Username (AdminDawood): ");
            admin = Console.ReadLine();
            Console.Write("Enter Password: ");
            adminpass = Console.ReadLine();
            Console.Clear();
            Console.Write("Do You Want To Change Any User's Password Or Do You Want To See Their History?");
            Console.WriteLine();
            Console.WriteLine("Press 1 For Password And 2 For History");
            char press = Convert.ToChar(Console.ReadLine());
            if (press == '1')
            {
                Console.Write("Which User's Password Do You Want To Change?");
                Console.WriteLine();
                Console.WriteLine("Press a For User 1, Press b For User 2 And Press c For User 3");
                char change = Convert.ToChar(Console.ReadLine());
                if (change == 'a')
                {
                    Console.Write("Choose Password: ");
                    string newpass1 = Console.ReadLine();
                    pass1 = newpass1;
                    Console.WriteLine("password change sucessfully:" +newpass1);
                    Console.ReadLine();
                }
                else if (change == 'b')
                {
                    Console.Write("Choose Password: ");
                    string newpass2 = Console.ReadLine();
                    pass2 = newpass2;
                    Console.WriteLine("password change sucessfully:" + newpass2);
                    Console.ReadLine();
                }
                else if (change == 'c')
                {
                    Console.Write("Choose Password: ");
                    string newpass3 = Console.ReadLine();
                    pass3 = newpass3;
                    Console.WriteLine("password change sucessfully:" + newpass3);
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Invalid Input!");
                }

            }
            else if (press == '2')
            {
                Console.WriteLine("Which id History Do You Want To See?........");
                Console.WriteLine();
                Console.WriteLine("Press a For User 1, Press b For User 2 And Press c For User 3");
                char history = Convert.ToChar(Console.ReadLine());
                if (history == '1')
                {
                    Console.WriteLine("Addition: " + add1 + "\nSubtraction: " + sub1 + "\nMultiplication: " + mul1 + "\nDivision: " + div1);
                    Console.ReadLine();
                }
                else if (history == '2')
                {
                    Console.WriteLine("Addition: " + add2 + "\nSubtraction: " + sub2 + "\nMultiplication: " + mul2 + "\nDivision: " + div2);
                    Console.ReadLine();
                }
                else if (history == '3')
                {
                    Console.WriteLine("Addition: " + add3 + "\nSubtraction: " + sub3 + "\nMultiplication: " + mul3 + "\nDivision: " + div3);
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Invalid Input!");
                }
            }
        }
    }
}*/




        //        {
        //            Console.WriteLine("lab 6");

        //            string m_s, g;
        //            int ag;

        //            Console.WriteLine("ENTER YOUR MARITAL STATUS");
        //            m_s = Console.ReadLine();

        //            if (m_s == "married" || m_s == "MARRIED")
        //            {
        //                Console.WriteLine("you are insured");
        //                Console.ReadLine();
        //            }
        //            if (m_s == "unmarried" || m_s == "UNMARRIED")
        //            {
        //                Console.WriteLine("ENTER YOUR GENDER");
        //                g = Console.ReadLine();

        //                Console.WriteLine("ENTER YOUR AGE");
        //                ag = Convert.ToInt32(Console.ReadLine());

        //                switch (g)
        //                {
        //                    case "male":

        //                        if (ag > 28)
        //                        {
        //                            Console.WriteLine("YOU ARE INSURED");
        //                            Console.WriteLine("You are Hired");
        //                            Console.ReadLine();
        //                        }
        //                        break;

        //                    case "MALE":

        //                        if (ag > 28)
        //                        {
        //                            Console.WriteLine("YOU ARE INSURED");
        //                            Console.WriteLine("You are Hired");
        //                            Console.ReadLine();
        //                        }
        //                        break;

        //                    case "female":

        //                        if (ag > 22)
        //                        {
        //                            Console.WriteLine("YOU ARE INSURED");
        //                            Console.WriteLine("You are Hired");
        //                            Console.ReadLine();
        //                        }
        //                        break;
        //                    case "FEMALE":

        //                        if (ag > 22)
        //                        {
        //                            Console.WriteLine("YOU ARE INSURED");
        //                            Console.WriteLine("You are Hired");
        //                            Console.ReadLine();
        //                        }
        //                        break;
        //                    default:
        //                        Console.WriteLine("YOU ARE NOT INSURED");
        //                        Console.ReadLine();
        //                        break;

        //                }
        //            }



            for (i=0; i<=10;i++)
            {
            Console.WriteLine("kiet");
            }

    }
}
}
        
    

