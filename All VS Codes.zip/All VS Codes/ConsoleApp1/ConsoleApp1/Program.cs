﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string u1, u2, u3, admin;
            string pass1, pass2, pass3, adminpass;
            double add1 = 0, add2 = 0, add3 = 0;
            double sub1 = 0, sub2 = 0, sub3 = 0;
            double mul1 = 0, mul2 = 0, mul3 = 0;
            double div1 = 0, div2 = 0, div3 = 0;
            Console.Write("Enter Username 1: ");
            u1 = Console.ReadLine();
            Console.Write("Enter Password: ");
            pass1 = Console.ReadLine();
            Console.Clear();
            Console.Write("Enter First Number: ");
            double n1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            double n2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Operations: +, -, *, /");
            Console.WriteLine();
            Console.Write("Choose An Operation From Above: ");
            char operation = Convert.ToChar(Console.ReadLine());
            if (operation == '+')
            {
                add1 = n1 + n2;
                Console.WriteLine("The Answer Is: " + add1);
            }
            else if (operation == '-')
            {
                sub1 = n1 - n2;
                Console.WriteLine("The Answer Is: " + sub1);
            }
            else if (operation == '*')
            {
                mul1 = n1 * n2;
                Console.WriteLine("The Answer Is: " + mul1);
            }
            else if (operation == '/')
            {
                div1 = n1 / n2;
                Console.WriteLine("The Answer Is: " + div1);
            }
            else
            {
                Console.WriteLine("Invalid Operation!");
            }
            Console.ReadKey();
            Console.Clear();
            Console.Write("Enter Username 2: ");
            u2 = Console.ReadLine();
            Console.Write("Enter Password: ");
            pass2 = Console.ReadLine();
            Console.Clear();
            Console.Write("Enter First Number: ");
            double num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            double num2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Operations: +, -, *, /");
            Console.WriteLine();
            Console.Write("Choose An Operation From Above: ");
            char ope = Convert.ToChar(Console.ReadLine());
            if (ope == '+')
            {
                add2 = num1 + num2;
                Console.WriteLine("The Answer Is: " + add2);
            }
            else if (ope == '-')
            {
                sub2 = num1 - num2;
                Console.WriteLine("The Answer Is: " + sub2);
            }
            else if (ope == '*')
            {
                mul2 = num1 * num2;
                Console.WriteLine("The Answer Is: " + mul2);
            }
            else if (ope == '/')
            {
                div2 = num1 / num2;
                Console.WriteLine("The Answer Is: " + div2);
            }
            else
            {
                Console.WriteLine("Invalid Operation!");
            }
            Console.ReadKey();
            Console.Clear();
            Console.Write("Enter Username 3: ");
            u3 = Console.ReadLine();
            Console.Write("Enter Password: ");
            pass3 = Console.ReadLine();
            Console.Clear();
            Console.Write("Enter First Number: ");
            double number1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            double number2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Operations: +, -, *, /");
            Console.WriteLine();
            Console.Write("Choose An Operation From Above: ");
            char Operation = Convert.ToChar(Console.ReadLine());
            if (Operation == '+')
            {
                add3 = number1 + number2;
                Console.WriteLine("The Answer Is: " + add3);
            }
            else if (Operation == '-')
            {
                sub3 = number1 - number2;
                Console.WriteLine("The Answer Is: " + sub3);
            }
            else if (Operation == '*')
            {
                mul3 = number1 * number2;
                Console.WriteLine("The Answer Is: " + mul3);
            }
            else if (Operation == '/')
            {
                div3 = number1 / number2;
                Console.WriteLine("The Answer Is: " + div3);
            }
            else
            {
                Console.WriteLine("Invalid Operation!");
            }
            Console.ReadKey();
            Console.Clear();
            Console.Write("Enter Username (Admin): ");
            admin = Console.ReadLine();
            Console.Write("Enter Password: ");
            adminpass = Console.ReadLine();
            Console.Clear();
            Console.Write("Do You Want To Change Any User's Password Or Do You Want To See Their History?");
            Console.WriteLine();
            Console.WriteLine("Press 1 For Password And 2 For History");
            char press = Convert.ToChar(Console.ReadLine());
            if (press == '1')
            {
                Console.Write("Which User's Password Do You Want To Change?");
                Console.WriteLine();
                Console.WriteLine("Press 1 For User 1, Press 2 For User 2 And Press 3 For User 3");
                char change = Convert.ToChar(Console.ReadLine());
                if (change == '1')
                {
                    Console.Write("Choose Password: ");
                    string newpass1 = Console.ReadLine();
                    pass1 = newpass1;
                }
                else if (change == '2')
                {
                    Console.Write("Choose Password: ");
                    string newpass2 = Console.ReadLine();
                    pass2 = newpass2;
                }
                else if (change == '3')
                {
                    Console.Write("Choose Password: ");
                    string newpass3 = Console.ReadLine();
                    pass3 = newpass3;
                }
                else
                {
                    Console.WriteLine("Invalid Input!");
                }
            }
            else if (press == '2')
            {
                Console.Write("Which User's History Do You Want To See?");
                Console.WriteLine();
                Console.WriteLine("Press 1 For User 1, Press 2 For User 2 And Press 3 For User 3");
                char history = Convert.ToChar(Console.ReadLine());
                if (history == '1')
                {
                    Console.WriteLine("Addition: " + add1 + "\nSubtraction: " + sub1 + "\nMultiplication: " + mul1 + "\nDivision: " + div1);
                }
                else if (history == '2')
                {
                    Console.WriteLine("Addition: " + add2 + "\nSubtraction: " + sub2 + "\nMultiplication: " + mul2 + "\nDivision: " + div2);
                }
                else if (history == '3')
                {
                    Console.WriteLine("Addition: " + add3 + "\nSubtraction: " + sub3 + "\nMultiplication: " + mul3 + "\nDivision: " + div3);
                }
                else
                {
                    Console.WriteLine("Invalid Input!");
                }
            }
            else
            {
                Console.WriteLine("Invalid Input!");
            }
        }
    }
}