﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dawood._14515.Assignment2.iictq4
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
