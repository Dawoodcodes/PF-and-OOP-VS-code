﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace KBC_Application
{
    class Program
    {
        public static string[] PlayerName = new string[3];
        public static string[] hotseat_player = new string[10];
        public static string[] won = new string[10];
        public static int game = 0;











        static void Main(string[] args)
        {
            int player = -1;
            while (true)
            {
                string[] preQuestions = new string[5];
                preQuestions[0] = "What Is The Resolution Of The Human Eye?";

                preQuestions[1] = "Which one is smallest ocean in the World?";

                preQuestions[2] = "Which one is the biggest island in the world?";

                preQuestions[3] = "Which continent has the highest number of countries?";

                preQuestions[4] = "Which country is also known as the 'Land of Rising Sun'?";

                string[] preQuestions_opA = { "576 Megapixels", "Pacific", "Finland", "asia", "Japan" };

                string[] preQuestions_opB = { "425 Megapixels", "Atlantic", "Borneo", "Europe", "Turkey" };

                string[] preQuestions_opC = { "365 Megapixels", "Indian", "Greenland", "North america", "Pakistan" };

                string[] preQuestions_opD = { "108 Megapixels", "Arctic", "Autralia", "Africa", "China" };

                string[] preQuestions_ans = { "A", "D", "C", "D", "A" };
                string adminUsername = "M.Dawood";
                string adminPass = "Dawood321";
                string id = "";
                string pass = "";
                player++;


                int select = 0;

                string[] PlayerAnswer = { "In", "In", "In" };
                Console.Clear();
                Console.WriteLine("$$$$$$$$$$ Inam Ghar $$$$$$$$$$");

                Console.WriteLine("\n1)******** Play***********\n2)*********** Login ADMIN**********");
                Console.Write("\nSelect ONE : ");
                select = Convert.ToInt32(Console.ReadLine());

                switch (select)
                {
                    case 1:
                        int i = 0;
                        introText();
                        Console.Clear();
                        Console.WriteLine("$$$$$$$$$$Enter Player Names For First Round$$$$$$$$$$");
                       
                        Console.Write("Player 1 : ");
                        PlayerName[0] = Console.ReadLine();
                        Console.Write("Player 2 : ");
                        PlayerName[1] = Console.ReadLine();
                        Console.Write("Player 3 : ");
                        PlayerName[2] = Console.ReadLine();
                        int hotseat = 0;
                        while (hotseat == 0)
                        {
                            if (i == preQuestions.Length)
                            { i = 0; }
                            Console.Clear();
                            Console.WriteLine(" Qualifying Player For Hot Seat");
                            Console.WriteLine("\nQuestion:\n{0}\n\nA - {1}\nB - {2}\nC - {3}\nD - {4}\n", preQuestions[i], preQuestions_opA[i], preQuestions_opB[i], preQuestions_opC[i], preQuestions_opD[i]);

                            if (PlayerAnswer[0] == "In")
                            {
                                Console.Write(PlayerName[0] + " Answer : ");
                                PlayerAnswer[0] = Console.ReadLine().ToUpper();
                            }
                            if (PlayerAnswer[1] == "In")
                            {
                                Console.Write(PlayerName[1] + " Answer : ");
                                PlayerAnswer[1] = Console.ReadLine().ToUpper();
                            }
                            if (PlayerAnswer[2] == "In")
                            {
                                Console.Write(PlayerName[2] + " Answer : ");
                                PlayerAnswer[2] = Console.ReadLine().ToUpper();
                            }
                            Console.WriteLine("");
                            Console.WriteLine("Correct Answer is \"" + preQuestions_ans[i] + "\"");
                            if (PlayerAnswer[0] == preQuestions_ans[i] && PlayerAnswer[1] != preQuestions_ans[i] && PlayerAnswer[2] != preQuestions_ans[i])
                            {
                                Console.WriteLine(PlayerName[0] + " is Qualifyied for Hot Seat");
                                Console.Write("\nPress Enter to Start the Game....");
                                Console.ReadKey();
                                PlayerAnswer[0] = "In";
                                PlayerAnswer[1] = "Out";
                                PlayerAnswer[2] = "Out";
                                hotseat_player[player] = PlayerName[0];
                                hotseat = 1;
                                starting();
                                questions();
                            }
                            else if (PlayerAnswer[1] == preQuestions_ans[i]
                                && PlayerAnswer[2] != preQuestions_ans[i] && PlayerAnswer[0] != preQuestions_ans[i])
                            {
                                Console.WriteLine(PlayerName[1] + " is Qualifyied for Hot Seat");
                                Console.Write("\nPress Enter to Start the Game....");
                                Console.ReadKey();
                                PlayerAnswer[0] = "Out";


                                PlayerAnswer[1] = "In";

                                PlayerAnswer[2] = "Out";
                                hotseat_player[player] = PlayerName[1];


                                hotseat = 1;
                                starting();
                                questions();


                            }
                            else if (PlayerAnswer[2] == preQuestions_ans[i] && PlayerAnswer[0] != preQuestions_ans[i] && PlayerAnswer[1] != preQuestions_ans[i])
                            {
                                Console.WriteLine(PlayerName[2] + " is Qualifyied for Hot Seat");

                                Console.Write("\nPress Enter to Start the Game....");

                                Console.ReadKey();
                                PlayerAnswer[0] = "Out";
                                PlayerAnswer[1] = "Out";


                                PlayerAnswer[2] = "In";
                                hotseat_player[player] = PlayerName[2];
                                hotseat = 1;
                                starting();
                                questions();
                            }
                            else if (PlayerAnswer[0] == preQuestions_ans[i] && PlayerAnswer[1] == preQuestions_ans[i] && PlayerAnswer[2] == preQuestions_ans[i])
                            {
                                Console.WriteLine("Draw Between " + PlayerName[0] + ", " + PlayerName[1] + " & " + PlayerName[2]);
                                PlayerAnswer[0] = "In";
                                PlayerAnswer[1] = "In";
                                PlayerAnswer[2] = "In";
                                Console.Write("\nPress Enter For New Question....");
                                Console.ReadKey();
                            }
                            else if (PlayerAnswer[0] != preQuestions_ans[i] 
                                && PlayerAnswer[1] != preQuestions_ans[i] && PlayerAnswer[2] != preQuestions_ans[i])
                            {
                                Console.WriteLine("No One Gave The Right Answer");
                                if (PlayerAnswer[0] != "Out")
                                { PlayerAnswer[0] = "In"; }
                                if (PlayerAnswer[1] != "Out")

                                { PlayerAnswer[1] = "In"; }

                                if (PlayerAnswer[2] != "Out")
                                { PlayerAnswer[2] = "In"; }

                                Console.Write("\nPress Enter For New Question....");
                                Console.ReadKey();
                            }
                            else if (PlayerAnswer[0] == preQuestions_ans[i] && PlayerAnswer[1] == preQuestions_ans[i] && PlayerAnswer[2] != preQuestions_ans[i])
                            {

                                Console.WriteLine("Draw Between " + PlayerName[0] + " & " + PlayerName[1]);
                                PlayerAnswer[0] = "In";
                                PlayerAnswer[1] = "In";
                                PlayerAnswer[2] = "Out";
                                Console.Write("\nPress Enter For New Question....");
                                Console.ReadKey();
                            }
                            else if (PlayerAnswer[0] == preQuestions_ans[i] && PlayerAnswer[2] == preQuestions_ans[i] && PlayerAnswer[1] != preQuestions_ans[i])
                            {
                                Console.WriteLine("Draw Between " + PlayerName[0] + " & " + PlayerName[2]);
                                PlayerAnswer[0] = "In";
                                PlayerAnswer[1] = "Out";
                                PlayerAnswer[2] = "In";
                                Console.Write("\nPress Enter For New Question....");
                                Console.ReadKey();
                            }
                            else if (PlayerAnswer[1] == preQuestions_ans[i] && PlayerAnswer[2] == preQuestions_ans[i] && PlayerAnswer[0] != preQuestions_ans[i])
                            {
                                Console.WriteLine("Draw Between " + PlayerName[1] + " & " + PlayerName[2]);
                                PlayerAnswer[0] = "Out";
                                PlayerAnswer[1] = "In";
                                PlayerAnswer[2] = "In";
                                Console.Write("\nPress Enter For New Question....");
                                Console.ReadKey();
                            }
                            i++;
                        }

                        break;
                    case 2:
                        Console.Clear();
                        Console.WriteLine("$$$$$$$$$$ Login $$$$$$$$$$");
                        Console.Write("\nUsername : ");
                        id = Console.ReadLine();
                        Console.Write("Password : ");
                        pass = Console.ReadLine();
                        if (id == adminUsername && pass == adminPass)
                        {
                            loginText();
                            int option = 0;
                            while (option != 2)
                            {
                                Console.Clear();
                                Console.WriteLine("$$$$$$$$$$ Admin PortAL $$$$$$$$$$");
                                Console.WriteLine("\n1 - History\n2 - Logout");
                                Console.Write("\nSelect : ");
                                option = Convert.ToInt32(Console.ReadLine());
                                switch (option)
                                {
                                    case 1:
                                        Console.Clear();
                                        Console.WriteLine("♕♕♕♕♕♕♕ Game History ♕♕♕♕♕♕♕\n");
                                        for (int j = 0; j < 10; j++)
                                        {
                                            Console.WriteLine("{0} - {1} {2}", j + 1, hotseat_player[j], won[j]);
                                        }
                                        Console.Write("\nPress Enter to go back to dashboard....");
                                        Console.ReadKey();
                                        break;
                                }
                            }
                        }
                        break;
                }
            }
        }

        static void introText()
        {
            

            Console.Write("\t\t\t\t***************Welcome in inam Ghar***************");
            Console.ReadLine();
            Console.Clear();
        }
        static void loginText()
        {
            Console.Clear();
            Console.Write("Login Successfully.......Press Enter***************");
            Console.ReadLine();
            Console.Clear();
        }
        static void starting()
        {
            Console.Clear();

            Console.Write("$$$$$$$$$$Press Enter to Start$$$$$$$$$$");
            Console.ReadLine();
            Console.Clear();
        }
        static void ques_text()
        {
            Console.Write("Question ::");
            Console.ReadLine();
        }
        static void amount_text()
        {
            Console.Write("$$$$$$$$$$Prizes in RS:");
            Console.ReadLine();
        }
        static void unlocked_text()
        {
            Console.Clear();
            Console.Write("lifeline quit option is unlockeded");
            Console.ReadLine();
            Console.Clear();
        }
       
        static void questions()
        {

            string[] questions = new string[10];
            questions[0] = "Which among the following is the brightest planet?";


            questions[1] = "In a Cricket World Cup match, who has scored the maximum runs in one inning?";

            questions[2] = "The First World War fought between …";

            questions[3] = "Word Urdu means:?";

            questions[4] = "How many letters are there in Urdu alphabets:?";

            questions[5] = "Who wrote the national anthem of Pakistan??";

            questions[6] = "Which peak is located in Karakorum Range?";

            questions[7] = "Give the number of railway stations in Pakistan:?";

            questions[8] = "What is the largest state in the US?";
            questions[9] = "What is the longest river in the world?";
            string[] questions_opA = { "Mercury", "Babar azam", "1914 and 1918", "Believers", "37", "Allama Iqbal", "Nanga Patbat", "980", "Montana", "Nile" };

            string[] questions_opB = { "Venus", "Virat Kholi", "1915 and 1920", "A group of students", "33", "Hafeez Jullundari", "Rakaposhi", "640", "California", "Yangtze" };

            string[] questions_opC = { "Mars", "Chris Gayle", "1914 and 1919", "Army", "39", "Mirza Adeeb", "K2", "880", "Maine", "Mekong" };

            string[] questions_opD = { "Neptune", "Martin Guptill", "1913 and 1917", "None of these", "41", "Sagar", "Takht-e-Sulaiman", "825", "Alaska", "Lena" };

            string[] questions_ans = { "B", "D", "A", "C", "A", "B", "C", "C", "D", "A" };
            string[] prize = { "25,000", "50,000", "70,000", "100,000", "300,000", "600,000", "1,200,000", "2,500,000", "5,000,000", "10,000,000" };

            string LifeLine_A = "Available";
            string LifeLine_C = "Available";
            string LifeLine_D = "Available";
            string LifeLine = "";
            string options = "on";
            string unlock_text = "on";

            for (int i = 0; i < 10; i++)
            {
                Console.Clear();
                if (i < 3)
                {
                    ques_text();
                    Console.Write(i + 1);
                    amount_text();
                    Console.Write(prize[i]);
                    Thread.Sleep(250);
                    Console.WriteLine("\n\n{0}", questions[i]);
                    Thread.Sleep(2500);
                    Console.WriteLine("\nA - {0}", questions_opA[i]);
                    Thread.Sleep(1000);
                    Console.WriteLine("B - {0}", questions_opB[i]);
                    Thread.Sleep(1000);
                    Console.WriteLine("C - {0}", questions_opC[i]);
                    Thread.Sleep(1000);
                    Console.WriteLine("D - {0}", questions_opD[i]);
                    Thread.Sleep(1000);
                    Console.Write("\nAnswer : ");
                    string select = Console.ReadLine().ToUpper();
                   
                    if (select == questions_ans[i])
                    {
                        won[game] = "Rs: " + prize[i];
                        Console.WriteLine("\n\"" + questions_ans[i] + "\" is the Correct Answer");
                        Console.WriteLine("You Got Rs: " + prize[i]);
                        Console.Write("\nPress Enter For Next Question....");
                        Console.ReadKey();
                    }
                    else
                    {
                        won[game] = "Rs: 0";
                        Console.WriteLine("\nYOU LOSE :(");
                        Console.WriteLine("You Got Rs: 0");
                        Console.WriteLine("\nCorrect Answer is \"" + questions_ans[i] + "\"");
                        Console.Write("\nPress Enter For Main Menu....");
                        Console.ReadKey();
                        game++;
                        break;
                    }

                }
                else if (i >= 3)
                {
                    if (i == 3 && unlock_text == "on")
                    {
                        unlocked_text();
                        unlock_text = "off";
                    }
                    ques_text();
                    Console.Write(i + 1);
                    amount_text();
                    Console.Write(prize[i]);
                    Thread.Sleep(250);
                    Console.WriteLine("\n\n{0}", questions[i]);
                    Thread.Sleep(2500);
                    Console.WriteLine("\nA - {0}", questions_opA[i]);
                    Thread.Sleep(1000);
                    Console.WriteLine("B - {0}", questions_opB[i]);
                    Thread.Sleep(1000);
                    Console.WriteLine("C - {0}", questions_opC[i]);
                    Thread.Sleep(1000);
                    Console.WriteLine("D - {0}", questions_opD[i]);
                    Thread.Sleep(1000);
                    if (options == "on")
                    {
                        Console.WriteLine("\n\"L\" for LifeLine");
                        Console.WriteLine("\"Q\" for Quit the Game");
                    }
                    string select = "";
                    string select2 = "";
                    if (LifeLine == "Double Dip")
                    {
                        Console.WriteLine("\nUsing Double Dip");
                        Console.Write("\nAnswer 1 : ");
                        select = Console.ReadLine().ToUpper();
                        Console.Write("Answer 2 : ");
                        select2 = Console.ReadLine().ToUpper();

                    }
                    else
                    {
                        if (LifeLine != "")
                        {
                            Console.WriteLine(LifeLine);
                        }
                        Console.Write("\nAnswer : ");
                        select = Console.ReadLine().ToUpper();
                    }

                    if (select == questions_ans[i] || select2 == questions_ans[i])
                    {
                       
                        select2 = "";
                        won[game] = "Rs: " + prize[i];
                        options = "on";
                        LifeLine = "";
                        Console.WriteLine("\n\"" + questions_ans[i] + "\" is the Correct Answer");
                        Console.WriteLine("You Got Rs: " + prize[i]);
                        Console.Write("\nPress Enter For Next Question....");
                        Console.ReadKey();
                    }
                    //LifeLine
                    else if (select == "L")
                    {
                        if (options == "off")
                        {
                            Console.Clear();
                            i--;
                            Console.WriteLine("\n\nYou have already used the LifeLine");
                            Console.Write("\nPress Enter to go back.....");
                            Console.ReadKey();
                            continue;
                        }
                        Console.Clear();
                        Console.WriteLine("$$$$$$$$$$ Select LifeLine $$$$$$$$$$\n");
                        if (LifeLine_A == "Available")
                        { Console.WriteLine("A - Ask the Expert"); }
                        if (LifeLine_C == "Available")
                        { Console.WriteLine("C - Call a Friend"); }
                        if (LifeLine_D == "Available")
                        { Console.WriteLine("D - Double Dip"); }
                        if (LifeLine_A == "Unavailable" && LifeLine_C == "Unavailable" && LifeLine_D == "Unavailable")
                        {
                            Console.WriteLine("-- No LifeLine Remaining --");
                            Console.Write("Press Enter to Go Back....");
                            Console.ReadKey();
                            i--;
                            continue;
                        }
                        Console.Write("\nChoose : ");
                        string choose = Console.ReadLine().ToUpper();
                        switch (choose)
                        {
                            case "A":
                                if (LifeLine_A == "Unavailable")
                                {
                                    Console.Clear();
                                    Console.WriteLine("\nYou already used Ask the Expert LifeLine");
                                    Console.Write("Press Enter to Go Back....");
                                    Console.ReadKey();
                                    i--;
                                    continue;
                                }
                                LifeLine_A = "Unavailable";
                                options = "off";
                                string Ask = questions_ans[i];
                                i--;
                               
                                LifeLine = ("\nExpert Suggested Option \"" + Ask + "\"");
                                Console.WriteLine(LifeLine);
                                Console.Write("Press Enter to Continue....");
                                Console.ReadKey();
                                break;
                            case "C":
                                if (LifeLine_C == "Unavailable")
                                {
                                    Console.Clear();
                                    Console.WriteLine("\nYou already used Call a Friend LifeLine");
                                    Console.Write("Press Enter to Go Back....");
                                    Console.ReadKey();
                                    i--;
                                    continue;
                                }
                                LifeLine_C = "Unavailable";
                                options = "off";
                                Random num = new Random();
                                string[] Call_Get = { questions_ans[i], "B", questions_ans[i], questions_ans[i], "C" };
                                string Call = Call_Get[num.Next(0, 5)];
                                i--;
                               
                                LifeLine = ("\nFriend Suggested Option \"" + Call + "\"");
                                Console.WriteLine(LifeLine);
                                Console.Write("Press Enter to Continue....");
                                Console.ReadKey();
                                break;
                            case "D":
                                if (LifeLine_D == "Unavailable")
                                {
                                    Console.Clear();
                                    Console.WriteLine("\nYou already used Double Dip LifeLine");
                                    Console.Write("Press Enter to Go Back....");
                                    Console.ReadKey();
                                    i--;
                                    continue;
                                }
                                LifeLine_D = "Unavailable";
                                options = "off";
                                i--;
                                LifeLine = "Double Dip";
                                Console.WriteLine("\nDouble Dip Has Been Applied");
                                Console.Write("Press Enter to Continue....");
                                Console.ReadKey();
                                break;
                        }



                    }
                    else if (select == "Q")
                    {
                        if (options == "off")
                        {
                            Console.Clear();
                            i--;
                            Console.WriteLine("\n\nYou have used the LifeLine, You can not Quit now");
                            Console.Write("\nPress Enter to go back.....");
                            Console.ReadKey();
                            continue;
                        }
                        Console.Clear();
                        won[game] = "Rs: " + prize[i - 1];
                        Console.WriteLine("\n\n\n\n\n\n\n\n\n\t\t\t\t\tYou Have Quited The Game");
                        Console.WriteLine("\t\t\t\t  Congratulations! You Win Rs: " + won[game]);
                        Console.Write("\n\n\n\n\n\n\n\n\n\nPress Enter For Main Menu....");
                        Console.ReadKey();
                        game++;
                        break;
                    }
                    else
                    {
                        
                        won[game] = "Rs: 0";
                        Console.WriteLine("\nYOU LOSE :(");
                        Console.WriteLine("You Got Rs: 0");
                        Console.WriteLine("\nCorrect Answer is \"" + questions_ans[i] + "\"");
                        Console.Write("\nPress Enter For Main Menu....");
                        Console.ReadKey();
                        game++;
                        break;
                    }
                }
                if (i == 9)
                {
                    won[game] = "Rs: " + prize[i];
                    Console.Clear();
                    Console.WriteLine("\n\n\n\n\n\n\n\n\n\n\t\t\t\t  Congratulations! You Win Rs: " + won[game]);
                    Console.Write("\n\n\n\n\n\n\n\n\n\nPress Enter For Main Menu....");
                    Console.ReadKey();
                    game++;
                    break;
                }
            }
        }
       
                }
            }
