﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2pflab._7sub
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i;
            i =0;
            while(i++<5)
            {
                Console.WriteLine(i);

            }
            Console.WriteLine("\n");
            i = 0;
            while(++i<5)
            { Console.WriteLine(i);}
            Console.ReadLine();
            }
        }
    }


