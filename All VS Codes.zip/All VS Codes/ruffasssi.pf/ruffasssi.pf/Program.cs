﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ruffasssi.pf
{
    internal class Program
    {

        class step3
        {
            public void playername()
            {
                Console.WriteLine("number of players");
                Console.WriteLine("************************************");

                int n = Convert.ToInt32(Console.ReadLine());
                string[] PN = new string[n];
                for (int i = 0; i < PN.Length; i++)
                {
                    Console.WriteLine("enter player" + (i + 1) + " name: ");
                    PN[i] = Console.ReadLine();
                }
                Console.WriteLine("player name");

                foreach (var item in PN)
                {
                    Console.WriteLine(item);
                }
            }
        class step4
        {
            public void oddoreven()
            {
                Console.WriteLine("check whether a number is even or odd:\n");
                Console.WriteLine("************************************");

                Console.WriteLine("\n\n");
                Console.WriteLine("input an integer :");
                int value = Convert.ToInt32(Console.ReadLine());
                int ans = value % 2;
                if (ans == 0)
                    Console.WriteLine("\n{0} is even integer.\n", value);
                Console.WriteLine("\n{0} is a odd integer.\n", value);
            }
        }


        static void Main(string[] args)
        {
            Console.WriteLine("enter any value");
            int a = Convert.ToInt32(Console.ReadLine());

           
                step3 obj = new step3();
                obj.playername();

                step4 obj1 = new step4();
                obj1.oddoreven();
                

                step1 obj2 = new step1();
                obj2.checknumber();

                step2 obj3 = new step2();
            obj3.loop1e();


                Console.Read();

            }
        class step2
        {
            public void loop1e()
            {
                int f1 = 0; int f2 = 1;
                Console.WriteLine("enter number");
                Console.WriteLine("*****************");

                int a = Convert.ToInt32(Console.ReadLine());
                if (a < 1)
                {
                    return;
                    Console.WriteLine(f1 + " ");
                }
                for (int i = 0; i <= a; i++)
                {
                    Console.WriteLine(f2 + " ");
                    int d = f1 + f2;
                    f1 = f2;
                    f2 = d;
                }
                Console.ReadKey();
            }
        }
        class step1
        {
            public void checknumber()
            {
                Console.WriteLine("check whether a number is positive or negative:\n");
                Console.WriteLine("************************************");
                Console.WriteLine("\n\n");
                Console.WriteLine("input an integer:");
                int value = Convert.ToInt32(Console.ReadLine());
                if (value >= 0)
                    Console.WriteLine("\n{0} is a positive number.\n", value);
                Console.WriteLine("\n{0} is a negative number.\n", value);
            }
        }
        
        
            }

        }
    }












        
        
    

    

