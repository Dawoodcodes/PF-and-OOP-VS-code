﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dawood._14515.pf.labtask11
{
    internal class Program
    {
        // static void Main(string[] args)
        //{
        //        NewClass obj = new NewClass();
        //        obj.PrintName();
        //    }
        //}
        //class NewClass
        //{
        //    public void PrintName()
        //    {
        //        Console.WriteLine("\t\t\t\t\t\tName=M.DAWOOd zahid\n\t\t\t\t\t\tID=14515" +
        //            "\n\t\t\t\t\t\tstudy at pafkiet\n\t\t\t\t\t\tPF lab task:11");
        //        Console.ReadLine();
        //    }
        //}



        //    int a;
        //    Console.WriteLine("enter table no");
        //    a = int.Parse(Console.ReadLine());
        //    table(a);
        //    Console.ReadLine();
        //}
        //public static int table(int x)
        //{
        //    for (int i = 0; i <= 10; i++)
        //    {
        //        Console.WriteLine(x + "x" + i + "=" + (x * i));
        //    }
        //    return 0;

        static void Main(string[] args)
        {
            Console.WriteLine("\tenter any number");
            int a = Convert.ToInt32(Console.ReadLine());
            newclass3 obj3 = new newclass3();
            obj3.playername();


            newclass2 obj2 = new newclass2();
            obj2.EVENorodd();

            newclass obj = new newclass();
            obj.fabnoics();

            Console.Read();
        }
        class newclass
        {
            public void fabnoics()
            {
                int f1 = 0; int f2 = 1;
                Console.WriteLine("\tenter number");
                int a = Convert.ToInt32(Console.ReadLine());
                if (a < 1)
                {
                    return;
                    Console.WriteLine(f1 + " ");
                }
                for (int i = 0; i <= a; i++)


                {
                    Console.WriteLine(f2 + " ");
                    int d = f1 + f2;
                    f1 = f2;
                    f2 = d;
                }
                Console.ReadKey();
            }
        }
        class newclass2
        {
            public void EVENorodd()
            {
                Console.WriteLine("\t number is even or odd:\n");

                Console.WriteLine("\n\n");
                Console.WriteLine("\tinput an number :");
                int value = Convert.ToInt32(Console.ReadLine());
                int ans = value % 2;
                if (ans == 0)
                    Console.WriteLine("\n{0} is even number.\n", value);
                Console.WriteLine("{0} is a odd number.\n", value);
            }
        }
        class newclass3
        {
            public void playername()
            {
                Console.WriteLine("\tEnter number of players");
                int n = Convert.ToInt32(Console.ReadLine());
                string[] PN = new string[n];
                for (int i = 0; i < PN.Length; i++)
                {
                    Console.WriteLine("enter player" + (i + 1) + " name: ");
                    PN[i] = Console.ReadLine();
                }
                Console.WriteLine("\tenter player name");

                foreach (var item in PN)
                {
                    Console.WriteLine(item);
                }


            }
        }
    }
}
    











        












