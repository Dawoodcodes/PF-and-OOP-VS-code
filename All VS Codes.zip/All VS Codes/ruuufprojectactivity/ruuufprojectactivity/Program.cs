﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace ruuufprojectactivity
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
    public class main
    {
        private SqlConnection connection;
        public static SqlConnection getconnection()
        {
            SqlConnection connection = new SqlConnection(@"");
            return connection;
        }

        public string Converter_string(string SQL)
        {
            try
            {
                SqlConnection con = main.getconnection();
                DataTable consultantable = new DataTable();
                string StringConsultant;
                SqlDataAdapter Consultantdataadapter = new SqlDataAdapter(SQL, con);
                Consultantdataadapter.Fill(consultantable);
                foreach (DataRow myrow in consultantable.Rows)
                {
                    StringConsultant = Convert.ToString(myrow[0]);
                    return StringConsultant;
                }

            }
            catch
            {
                throw;
            }
            return "0";
        }
        public void Excute(string SQL)
        {
            try
            {
                SqlConnection con = main.getconnection();
                DataTable consultantable = new DataTable();
                SqlDataAdapter Consultantdataadapter = new SqlDataAdapter(SQL, con);
                Consultantdataadapter.Fill(consultantable);
            }
            catch
            {
                throw;
            }
        }
    }

    using System.Net;

    namespace useractivity
    {
        public partial class frmLogin : Form
        {
            public frmLogin()
                public static string CIP = "";
            public static string EmpNo = "1";
            public static string username = "1";

            SqlConnection connection = main.getconnection();

            private void getIP()
            {
                IPHostEntry host;
                host = Dns.GetHostEntry(Dns.GetHostName());
                foreach(IPAddress ip in host.AddressList)
                {
                    if(ip.AddressFamily.ToString() == "INterNETWORK")
                    {
                        CIP = ip.ToString();

                             
                    }
                }
                IbICP.Text = CIP;
            }
            private void FrmLogin_load(object sender,EventArgs e)
            {
                getIP();
            }
            private void button1_click(object sender,EventArgs e)
            {
                if((txtusername.Text ==""))
                {
                    MessageBox.show("PLease enter username");
                }
                else if ((txtpassword.Text ==""))
                {
                    MessageBox.show("PLease enter Password");
                }
                else
                {
                    string Login = "Login";
                    main code = new main();
                    string SqlEmpNo = "Select EmployeeNO Login where username='" + Convert.ToString(txtusername.Text) + "' AND PASSWORD='" + Convert.ToString(txtpassword.Text) + "'";
                    EmpNo = code.Converter_string(SqlEmpNo).ToString();
                    if(EmpNo!="")
                    {
                        string SqlLoginName = "select username from Login where EmployeeNo='" + Convert.ToString(EmpNo) + "'";
                        username=code.Converter_string(SqlLoginName).ToString();
                        code.Excute(@"insert into User_Activity_Log values('" + Convert.ToString(txtusername.Text) + "','" + EmpNo + "','" + DateTime.Now + "','" + Login + "','" + CIP + "')");


                        FrmActivity frmmain = new FrmActivity();
                        frmmain.windowState = new FormWindowState.Maximized;
                        this.Hide();
                        frmmain.Show();

                    }
                    else
                    {
                        MessageBox.Show("invalid password");
                        txtpassword.Text = "";
                    }
                }
            }


        }
           
    }
}
