﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

namespace prrrrrooooooooo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int[] marks = new int[5] { 99, 98, 92, 97, 95 };
            ////Showing value of Array
            //Console.WriteLine("1st value:\t"+ marks[0]);
            //Console.WriteLine("2nd value:\t"+ marks[1]);
            //Console.WriteLine("3rd value:\t"+ marks[2]);
            //Console.ReadLine();


            //            int i;
            //            int[] bbb = new int[5]; // 5 size array // Accepting value from user
            //            for (i = 0; i < 5; i++)
            //            {
            //                Console.Write("\nEnter your number:\t");
            //                //Storing value in an array
            //                bbb[i] = Convert.ToInt32(Console.ReadLine());
            //            } //Printing the value on console
            //            for (i = 0; i < 5; i++)
            //            {
            //                Console.WriteLine("you entered " + bbb[i]);
            //            }
            //            Console.ReadLine();


            //            int[,] a = new int[5, 2] { { 0, 0 }, { 1, 2 }, { 2, 4 }, { 3, 6 }, { 4, 8 } };
            //            int  j;
            //            /* output each array element's value */
            //            for (i = 0; i < 5; i++)
            //            {
            //                for (j = 0; j < 2; j++)
            //                { Console.WriteLine("a[{0},{1}] = {2}", i, j, a[i, j]); }
            //            }
            //            Console.ReadKey();
            //        }

            //    }
            //}




            ////----------matrix-----------------

            //            Console.WriteLine("matrix_rows");
            //            int matrix_rows = Convert.ToInt32(Console.ReadLine());

            //            double[,] matrix = new double[matrix_rows, matrix_rows];

            //            for (int i = 0; i < matrix_rows; i++)
            //            {
            //                for (int j = 0; j < matrix_rows; j++)
            //                {
            //                    Console.Write("enter value for ({0},{1}): ", i, j);
            //                    matrix[i, j] = double.Parse(Console.ReadLine());
            //                }
            //            }
            //            Console.WriteLine("----------------------------");
            //            for (int i = 0; i < matrix_rows; i++)
            //            {
            //                for (int j = 0; j < matrix_rows; j++)
            //                {
            //                    Console.Write(matrix[i, j] + "\t");
            //                }
            //                Console.WriteLine();
            //            }


            //            Console.ReadKey();
            //        }

            //    }
            //}


            //----------add num----------
            //            int n, sum = 0;
            //            Console.Write("Enter a number: ");
            //            n = int.Parse(Console.ReadLine());
            //            sum = 1;
            //            while (n != 0)
            //            {
            //                sum = sum * (n % 10);
            //                n = n / 10;
            //            }
            //            Console.Write("Mulitiply is= " + sum);
            //            Console.ReadLine();
            //        }
            //    }
            //}


//            //---------q4-------------
//            int i, n, sum = 0;


//            Console.Write("input number of terms : ");
//            n = Convert.ToInt32(Console.ReadLine());
//            Console.Write("\nthe odd numbers are :");
//            for (i = 1; i <= n; i++)
//            {
//                Console.Write("{0} ", 2 * i - 1);
//                sum += 2 * i - 1;
//            }
//            Console.Write("\nthe sum of odd natural number upto {0} terms : {1} \n", n, sum);
//            Console.ReadLine();
//        }
//    }
//}




//String strFile = File.ReadAllText("f:\\daw.txt");

//strFile = strFile.Replace("675", "0");

//File.WriteAllText("f:\\daw2.txt", strFile);
//Console.ReadLine();


//--------------------write------------------------


//string str = "A";

//FileStream fs = new FileStream("f:\\sauood.txt", FileMode.Append, FileAccess.Write);
//StreamWriter sw = new StreamWriter(fs);
//while (str != "")
//{
//    Console.WriteLine("input");
//    str = Console.ReadLine();
//    sw.WriteLine(str);
//}
//sw.Close();
//fs.Close();
//-----------------replace-----------------
//string strFile = File.ReadAllText("f:\\sauood.txt");
//strFile = strFile.Replace("15", "98");
//File.WriteAllText("f:\\sauood.txt",strFile);
//Console.ReadLine();
//-----------------read-----------------
//FileStream fs = new FileStream("f:\\sauood.txt", FileMode.Open, FileAccess.Read);
//StreamReader sr = new StreamReader(fs);
//string str=sr.ReadLine();
//while(str != null)
//{
//    Console.WriteLine(str);
//    str = sr.ReadLine();
//}
//fs.Close();
//sr.Close();
//Console.ReadLine();
//-------------------search--------------------
//FileStream fs=new FileStream("f:\\sauood.txt", FileMode.Open, FileAccess.Read);
//StreamReader sr=new StreamReader(fs);
//Console.WriteLine("input");
//string input=Console.ReadLine();
//string str = sr.ReadLine();
//while (str != null)
//{
//    if (str.Contains(input))
//    {
//        Console.WriteLine("fouded" + str);
//    }
//    str = sr.ReadLine();
//}Console.ReadLine();    
//fs.Close();
//sr.Close();

//        }
//    }
//}

