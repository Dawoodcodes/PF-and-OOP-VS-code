﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace raff
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string firstName = "syed";
            const int totalMarks = 400;
            Console.WriteLine(firstName);
            Console.WriteLine(totalMarks);
            totalMarks = 200;
            Console.WriteLine(totalMarks);
            
        }
        }
    }

