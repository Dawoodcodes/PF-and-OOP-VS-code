using System.Data;
using System.Data.SqlClient;

namespace practice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con=new SqlConnection(@"Data Source=-ROCKSTAR-\SQLEXPRESS;Initial Catalog=exxp;Integrated Security=True");
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue.ToString() == "91")
            {
                clscity[] arrcity = new clscity[]
                {
                    new clscity{text="Bombay",value="91.1"},
                    new clscity{text="Mombai",value="91.2"},
                    new clscity{text ="New Delhi",value="91.3"}
                };
                comboBox2.DataSource = arrcity;
                comboBox2.ValueMember = "value";
                comboBox2.DisplayMember = "text";
            }
            else
            {
                clscity[] arrcity = new clscity[]
                {
                    new clscity{text="Karachi",value="92.1"},
                    new clscity{text="Lahore",value="92.2"},
                    new clscity{text ="Peshawar",value="92.3"}
                };
                comboBox2.DataSource = arrcity;
                comboBox2.ValueMember = "value";
                comboBox2.DisplayMember = "text";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            clscountry[] arrcountry = new clscountry[]
            {
                new clscountry{text="Pakistan", value="92"},
                new clscountry{text="India", value="91"}
            };
            comboBox1.DataSource = arrcountry;
            comboBox1.DisplayMember = "text";
            comboBox1.ValueMember = "value";




            //string select = "select from * Tbl_info";
            //SqlDataAdapter dataAdapter = new SqlDataAdapter(select, con); //c.con is the connection string
            //SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

            //DataTable table = new DataTable();
            ////dataAdapter.Fill(table);
           // dataGridView1.DataSource=con;
            //dataGridView1.ReadOnly = true;
            //dataGridView1.DataSource = "Tbl_info";

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        { }


        public class clscity
        {
            public string value { get; set; }
            public string text { get; set; }
        }
        public class clscountry
        {
            public string value { get; set; }
            public string text { get; set; }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            string query = "insert into Tbl_info (Name, Cource) values('" + txtName.Text + "','" + txtCource.Text + "')";
            // SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(dt);
            //DataGridView.DataSource = dt;
            con.Close();
            // dataGridView1.DataSource = "Tbl_info";
            // dataGridView1.DataMember = "Tbl_info";
            ///






        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //dataGridView1.DataSource = "Tbl_info";
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string query = "update Tbl_info set Name='" + txtName.Text + "' where Cource='" + txtCource.Text + "'";
            SqlCommand command = new SqlCommand(query, con);
            con.Open();
            command.ExecuteNonQuery();
            con.Close();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string query = "delete from Tbl_info where Cource='" + txtCource.Text+"'";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            if (txtconpass.Text==txtpass.Text)
            {
                btnsubmit.Enabled = true;
                PassError.Text = "";
            }
            else
            {
                PassError.Text = "your password is not same";
                btnsubmit.Enabled = false;
            }
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string name = txtfirstname.Text;
            string last = txtlastname.Text;
            string email = txtemail.Text;
            string contact = txtcontact.Text;
            string gender;
            if (Male.Checked==true)
            {
                gender = Male.Text;
            }
            else
            {
                gender = Female.Text;

            }
            string address = txtaddress.Text;
            string user = txtusername.Text;
            string pass=txtpass.Text;

            MessageBox.Show(name + "\n" + last + "\n" + email + "\n" + contact + "\n" + gender + "\n" + address + "\n" + user + "\n" + pass);
            
        }
    }
}

