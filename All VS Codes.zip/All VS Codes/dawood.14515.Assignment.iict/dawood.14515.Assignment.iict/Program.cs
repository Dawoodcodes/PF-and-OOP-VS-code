﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dawood._14515.Assignment.iict
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
