﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dawood._14515
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* int card = 0;
             int sweet = 0;
             int stationary = 0;
             int toys = 0;
             int[] array = new int[280];
             Console.WriteLine("please input the card");
             int code = Convert.ToInt32(Console.ReadLine());
             code = (code / 100);
             for (int i = 0; i < 4; i++)
             {
                 if (code == 0)
                 {
                     card += 1;
                     Console.WriteLine("card");
                 }
                 else if (code == 1)
                 {
                     sweet += 1;
                     Console.WriteLine("sweet");
                 }
                 else if (code == 2)
                 {
                     stationary += 1;
                     Console.WriteLine(" stationary");
                 }
                 else if (code == 3)
                 {
                     toys += 1;
                     Console.WriteLine("toys");
                 }
             }
             Console.WriteLine("total number of item is: " + "total");
             Console.ReadLine();*/







            /*Random random = new Random();
            int sum = 0;
            Console.WriteLine("input number");
            int n=Convert.ToInt32(Console.ReadLine());
            int[] array = new int[100];
            for (int i = 0; i < n; i++)
            {
                int x = random.Next(100);
                array[i] = x;
                Console.WriteLine(array[i] + " ");
                sum += array[i];
            }
            int mx = array[0];
            int mn = array[0];
            for (int i = 1; i < array[i]; i++)
            {
                if (array[i] > mx)
                {
                    mx = array[i];
                }
                if (array[i] < mn)
                {
                    mn = array[i];
                }
                for (int j = 1; i < array[i]; i++)
                {
                    if (array[i] > mx)
                    {
                        mx = array[i];
                    }
                    if (array[i] < mn)
                    {
                        mn = array[i];
                    }

                }
                double avg = sum / 20;
                Console.WriteLine("\nhighest number is : {0}\n", mx);
                Console.WriteLine("\nlowest number is : {0}\n", mn);
                Console.WriteLine("average from array is " + avg);
                Console.ReadLine();*/







            /* Console.WriteLine("how namy names you want to enter");
             int N = Convert.ToInt32(Console.ReadLine());

             string[] name = new string[N];

             for (int i = 0; i < name.Length; i++)
             {
                 Console.WriteLine("enter name" + (i + 1) + "name");
                 name[i] = Console.ReadLine();

             }
             Console.WriteLine("enter name");
             Console.WriteLine("---------");

             foreach (var item in name)
             {
                 Console.WriteLine(item);
             }
             Console.ReadLine();
            */








            /* int num;
             Console.WriteLine("how many element you want to enter in array");
             var N = int.Parse(Console.ReadLine());
             int[] number = new int[N];
             int i = 0;
             for (i = 0; i < (N - 1); i++)
             {
                 Console.WriteLine("enter number: ");
                 num = int.Parse(Console.ReadLine());
                 number[i] = N;
             }
             int sum = number[N - 2] + number[0];
             Console.WriteLine(sum);
             Console.ReadLine();*/







            // --------------------lab#9---------------------------

            /*int[] arr = new int[9];
            for (int i = 0; i < 9; i++)
            {
                Console.Write("enter element at index[" + i + "]: ");
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            int[,] data = new int[9, 9];
            int r = 1;
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    data[i, j] = (arr[j] * r);
                }
                r++;
            }

            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    Console.Write(data[i, j] + ", ");
                }
                Console.WriteLine();
            }
            Console.ReadKey();

            Console.ReadLine();*/











            string[] periods = { "Period 1", "Period 2", "Period 3 ", "Period 4" };
            string[,] schedule = {
                             {" Monday   ",    "PF  ",     "PF  ",       "OFF      ",   "OFF     "},
                             {" Tuesday  ",    "IICT",     "IICT",       "OFF      ",   "OFF     "},
                             {" Wednesday",    "OFF ",     "OFF ",       "PIS      ",   "PIS     "},
                             {" Thursday ",    "VLM ",      "VLM",       "PF Lab   ",   "PF Lab  "},
                             {" Friday   ",    "OFF ",      "OFF",       "IICT Lab ",   "IICT Lab"},
                         };
            Console.WriteLine("\n");
            Console.Write("                   " + periods[0]);
            Console.Write("       " + periods[1]);
            Console.Write("       " + periods[2]);
            Console.Write("           " + periods[3]);
            Console.WriteLine("\n");
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.Write(schedule[i, j] + "           ");
                }

                Console.ReadKey();

                Console.ReadLine();



            }
        }
    }
}

