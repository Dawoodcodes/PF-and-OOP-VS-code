namespace WinFormsApp1lab03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            country[] arrcountry = new country[]
            {
                new country{Text="Pak",Value="92"},
                new country{Text="ind",Value="91"},
            };
            comboBox1.DataSource = arrcountry;
            comboBox1.ValueMember = "Value";
            comboBox1.DisplayMember = "Text";

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            city[] arrcountry = new city[]
            { 
             
    
            comboBox2.DataSource = arrcountry;
            comboBox2.ValueMember = "Value";
            comboBox2.DisplayMember = "Text";
        }

        
    public class country
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
    public class city
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}