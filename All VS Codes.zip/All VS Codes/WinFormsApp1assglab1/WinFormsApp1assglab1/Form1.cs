namespace WinFormsApp1assglab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            clscountry[] arrctry = new clscountry[]
            {
                new clscountry{text="Pakistan",value="92"},
                new clscountry{text="India",value="91"},
                 new clscountry{text="Australia",value="93"},

            };
            comboBox1.DataSource = arrctry;
            comboBox1.ValueMember = "value";
            comboBox1.DisplayMember = "text";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedcountryid = comboBox1.SelectedValue.ToString();
            clscity[] arrcity = new clscity[]
            {
                new clscity{cityid="01",cityName="Karachi",countryid="92"},
                 new clscity{cityid="02",cityName="Lahore",countryid="92"},
                  new clscity{cityid="03",cityName="Delhi",countryid="91"},
                   new clscity{cityid="04",cityName="Bombay",countryid="91"},
                    new clscity{cityid="05",cityName="Melbourne",countryid="93"},
                     new clscity{cityid="06",cityName="Sidny",countryid="93"},
            };
            comboBox2.DataSource = arrcity.Where(w => w.countryid == selectedcountryid).ToList();
            comboBox2.ValueMember = "cityid";
            comboBox2.DisplayMember = "cityName";
        }
    }

    public class clscountry
    {
        public string text { get; set; }
        public string value { get; set; }
        public string cityid { get; set; }
        public string cityName { get; set; }
        public string countyid { get; set; }
    }
    public class clscity
    {
        public string text { get; set; }
        public string value { get; set; }
        public string cityid { get; set; }
        public string cityName { get; set; }
        public string countryid { get; set; }
    }

}